import image1 from "../assets/images/image-retro-pcs.jpg";
import image2 from "../assets/images/image-top-laptops.jpg";
import image3 from "../assets/images/image-gaming-growth.jpg";


export const Footer = () => {
  return (
    <div id="footer" className="flex justify-between mt-20">
        <div className="sm:flex ">
            <div className=" h-[200px] w-[100px] flex-1">
                <img  className="h-full w-[150px]"src={image1} alt=""/>
            </div>
            <div className="flex-1 pr-6">
                <p className="text-slate-300 text-3xl mb-[18px] font-bold">01</p>
                <h2 className="font-bold mb-[18px] hover:text-orange-300 cursor-pointer">Reviving Retro PCs</h2>
                <p className="text-slate-400 text-[16px]">What happens when old PCs are given modern upgrades?</p>    
            </div>
        </div>
        <div className="sm:flex">
            <div className="w-[100px] h-[200px] flex-1">
                <img className="h-full w-[150px]" src={image2} alt=""/>
            </div>
            <div className="flex-1 pr-6">
                <p className="text-slate-300 text-3xl mb-[18px] font-bold">02</p>
                <h2 className="font-bold mb-[18px] hover:text-orange-300 cursor-pointer">top 10 laptops of 2022</h2>
                <p className="text-slate-400 text-[16px]"> Our best picks for various needs and budgets</p>    
            </div>
        </div>
        <div className="sm:flex">
            <div className="w-[100px] h-[200px] flex-1">
                <img className="h-full w-[150px]"src={image3} alt=""/>
            </div>
            <div className="pr-6 flex-1">
                <p className="text-slate-300 text-3xl mb-[18px] font-bold">03</p>
                <h2 className="font-bold mb-[18px] hover:text-orange-300 cursor-pointer">the Growth of Gaming</h2>
                <p className="text-slate-400 text-[16px]">How the pandemic has sparked fresh oppotunities</p>    
            </div>
        </div>
    </div>
    
    
  )
}

export default Footer