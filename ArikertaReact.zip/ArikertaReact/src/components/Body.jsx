import desktop from "../assets/images/image-web-3-desktop.jpg"

export const Desktop = () => {
    return (
        <div id="nagusia" className="flex justify-around ">
            <div id="ezkerAldea" className="w-3/4 pr-12 ">
                <img className="h-4/6 w-full" src={desktop} alt=""/>
                <div className="sm:flex ">
                    <div className="flex-1 py-6">
                        <h1 className="text-[40px] sm:text-[58px] leading-none font-bold">The Bright Future of Web 3.0?</h1>
                    </div>
                    <div className="flex-1 pt-9">
                        <p className="text-[13px] mb-10 sm:text-[15px]">We dive into the next evolution of the web that claimns to put the power of the platforms back into the hands of the people. But is it really fulfilling its promise?</p>
                        <button className=" bg-orange-600 w-32 h-16 text-white hover:bg-slate-950" type="button">READ MORE</button>
                    </div> 
                </div>
            </div>
            <div id="eskubiALdea" className="w-1/4 bg-slate-950 text-white pl-6">
                <h1 className="pt-8 text-orange-300 text-5xl font-bold pb-10">New</h1>
                <p className="font-bold text-2xl pb-2 cursor-pointer hover:text-orange-300">Hydrogen VS Electric cars</p>
                <p className="pb-8 text-[15px]">Will hydrogen-fueled cars ever catch up to EVs</p>
                <hr className="pb-8"/>
                <h1 className="font-bold text-2xl pb-2 cursor-pointer hover:text-orange-300">The Downsides of AI Artistry</h1>
                <p className="pb-8 text-[15px]">What are the possible adverse effects of on-demand AI image generation</p>
                <hr className="pb-8"/>
                <h1 className="font-bold text-2xl pb-2 cursor-pointer hover:text-orange-300">Is VC Funding Drying Up?</h1>
                <p className="pb-8 text-[15px]">Private funding by VC firms is down 50% YOY. We take a look at what that means.</p>
            </div>
        </div>  
    )
}

export default Desktop