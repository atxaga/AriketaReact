import logo from "../assets/images/logo.svg";

export const Header = () => {
  return (
    <header className="flex justify-between my-14">
        <img src={logo} alt="" />
        <nav className="flex space-x-4 text-slate-500 pr-10">
          <input className="hover:text-orange-500 pr-8" type="button" value="Home"/>
          <input className="hover:text-orange-500 pr-8" type="button" value="New"/>
          <input className="hover:text-orange-500 pr-8" type="button" value="Popular"/>
          <input className="hover:text-orange-500 pr-8" type="button" value="Trending"/>
          <input className="hover:text-orange-500" type="button" value="Categories"/>
        </nav>
    </header>
  )
}

export default Header